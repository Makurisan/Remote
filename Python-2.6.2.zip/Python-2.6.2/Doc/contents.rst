%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 Python Documentation contents
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

.. toctree::

   whatsnew/index.rst
   tutorial/index.rst
   using/index.rst
   reference/index.rst
   library/index.rst
   extending/index.rst
   c-api/index.rst
   distutils/index.rst
   install/index.rst
   documenting/index.rst
   howto/index.rst
   glossary.rst

   about.rst
   bugs.rst
   copyright.rst
   license.rst
