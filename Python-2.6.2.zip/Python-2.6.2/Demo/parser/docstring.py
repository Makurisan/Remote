"""Some documentation.
"""
