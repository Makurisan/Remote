#! /bin/sh

# If you can't get this to work, your web server isn't set up right

echo Content-type: text/plain
echo
echo Hello world
echo This is cgi0.sh
