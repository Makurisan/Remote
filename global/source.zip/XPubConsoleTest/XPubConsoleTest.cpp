// XPubConsoleTest.cpp : Defines the entry point for the console application.
//
#include <string>
#include "stdafx.h"
#include <shellapi.h>
#include "../XPubTagBuilder/XPubTagBuilderErr.h"
#include "../XPubTagBuilder/XPubTagBuilder.h"

#pragma comment(lib, "shell32.lib")

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	printf("Tagbuilder Test command line\n");
	int nID = XPubTagBuilderInit();
	if(nID != XPubTagBuilder_Alloc_Err)	{
		printf("Tagbuilder was initialized\n");
		
		std::string docfilepath;
		std::string sdir("C:\\Daten\\temp\\");		// Zielverzeichnis der Test pdf

// PDF
		std::string sload;

		//// erstellt PDF im Verzeichnis Daten	
		//docfilepath = sdir + "Test.pdf";
		//nRet = XPubTagBuilderToPDFFile(nID, "Dies ist ein Test...", (char*)docfilepath.c_str());
		//if(nRet == XPubTagBuilder_OK)
		//	printf("Document '%s' was created successfully\n", docfilepath.c_str());
		//else	
		//	printf("Error creating Document '%s' \n", docfilepath.c_str());

		// erstellt weiteres Dokument mit Text, in welchem ein Wort fett gedruckt wird
		docfilepath = sdir + "TestSchadenText13.pdf";
		DeleteFile(sdir.c_str());


//#define _PDF_INLINE_CREATE

#ifdef _PDF_INLINE_CREATE	
		sload += "<margins left=\"14\" top=\"10\" right=\"10\" bottom=\"10\">";
		sload += "<header>Example";


		sload += "<template name=\"C:\\PROGRAM FILES (X86)\\WWI\\WAA\\TEST\\IEFA001P\\PARM\\Syka014p.sse\" mode=\"-1\">";
		//sload += "<template name=\"C:\\Daten\\Syka014p.sse\" mode=\"-1\">";
		sload += "<template name=\"C:\\PROGRAM FILES (X86)\\WWI\\WAA\\TEST\\IEFA001P\\PARM\\Syka045p.sse\" mode=\"0\">";
		//sload += "<template name=\"C:\\PROGRAM FILES (X86)\\WWI\\WAA\\TEST\\IEFA001P\\PARM\\Syka019p.sse\" mode=\"0\">";
		sload += "<formfield name=\"Name_VN\" value=\"Gilt f�r alle Fahrzeugarten\">";

		std::string sdata = /*"Dies <bold>ist</bold> ein Test...<par>" +*/ sload;
		nRet = XPubTagBuilderToPDFFile(nID, (char*)sdata.c_str(), (char*)docfilepath.c_str());

#else

		//getchar();

		std::string _filepath = "C:\\Daten\\temp\\ordner\\";
		_filepath += "20250818150909.000002-DIKSDA1P.pdf.xpubtag";

		// Use ShellExecute to open the PDF file with the default PDF viewer
		HINSTANCE result = ShellExecute(
			NULL,       // Handle to the parent window, NULL if not applicable
			"open",    // Operation to perform, "open" to open/view the file
			_filepath.c_str(),    // Path to the file
			NULL,       // Parameters if required, NULL if not
			NULL,       // Default directory, NULL to use the current directory
			SW_SHOW     // Show command, SW_SHOW to display the window normally
		);



		HANDLE hFile = CreateFile(_filepath.c_str(),  // file to open
                       GENERIC_READ,          // open for reading
                       FILE_SHARE_READ,       // share for reading
                       NULL,                  // default security
                       OPEN_EXISTING,         // existing file only
                       FILE_ATTRIBUTE_NORMAL, // normal file
                       NULL);                 // no attr. template

		DWORD dwWord = GetFileSize(hFile, NULL);
		char* inBuffer = (char*) malloc(dwWord+1);

		DWORD dInLength;
    if( FALSE == ReadFile(hFile, inBuffer, dwWord, &dInLength, NULL) )
    {
        printf("Unable to read from file.\n GetLastError=%08x\n", GetLastError());
        CloseHandle(hFile);
				free(inBuffer);
        return -1;
    }
		inBuffer[dwWord] = 0;
		int nRet = XPubTagBuilderToPDFFile(nID, (char*)inBuffer, (char*)docfilepath.c_str());
    CloseHandle(hFile);
		free(inBuffer);
#endif

		if (nRet == XPubTagBuilder_OK) {
			printf("Document '%s' was created successfully\n", docfilepath.c_str());
#ifdef _WIN32
				// Use ShellExecute to open the PDF file with the default PDF viewer
				HINSTANCE result = ShellExecute(
					NULL,       // Handle to the parent window, NULL if not applicable
					"open",    // Operation to perform, "open" to open/view the file
					docfilepath.c_str(),    // Path to the file
					NULL,       // Parameters if required, NULL if not
					NULL,       // Default directory, NULL to use the current directory
					SW_SHOW     // Show command, SW_SHOW to display the window normally
				);
#endif
		}
		else	
			printf("Error creating Document '%s' \n", docfilepath.c_str());

// RTF
#ifdef _RTF_CREATE
		docfilepath = sdir + "Test.rtf";
		nRet = XPubTagBuilderToRTFFile(nID, "Dies <bold>ist</bold> ein Test...", (char*)docfilepath.c_str());
		if(nRet == XPubTagBuilder_OK)
			printf("Document '%s' was created successfully\n", docfilepath.c_str());
		else	
			printf("Error creating Document '%s' \n", docfilepath.c_str());
#endif

		XPubTagBuilderClose(nID);
		printf("Tagbuilder was closed\n");

	}
	//fgetc(stdin);
	return 0;
}

