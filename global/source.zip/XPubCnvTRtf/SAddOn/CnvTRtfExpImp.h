

#ifdef EXPORT_XPUBCNVTRTF
#define XPUBCNVTRTF_EXPORTIMPORT __declspec(dllexport)
#else
#define XPUBCNVTRTF_EXPORTIMPORT __declspec(dllimport)
#endif

