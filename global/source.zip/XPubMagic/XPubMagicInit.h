
extern void XPubMagicInit(HANDLE hModule, char* pModuleName/*=0*/);
extern void XPubMagicRelease();