
void XPubModelInit();
void XPubModelTerminate();