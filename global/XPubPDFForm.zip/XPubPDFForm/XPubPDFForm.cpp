// XPubPDFForm.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "PDFLibrary.h"
#include "XPubPDFForm.h"
#include <iostream>
#include <string>
#include <locale>
#include <codecvt>

XPubPDFForm::XPubPDFForm()
{
	int nSuccess;
	InstanceID = DPLCreateLibrary(); 
    nSuccess = DPLUnlockKeyA(InstanceID, "j33496ii9q65976c97fu8pb8y");
}

XPubPDFForm::~XPubPDFForm()
{
	DPLReleaseLibrary(InstanceID);
}
int XPubPDFForm::LoadFromFile(const std::string& FileName)
{
	return DPLLoadFromFileA(InstanceID, (char*)FileName.c_str(), NULL);
}

int XPubPDFForm::SaveToFile(const std::string& FileName)
{
	return DPLSaveToFileA(InstanceID, (char*)FileName.c_str());
}

int XPubPDFForm::UpdateAndFlattenFormFields()
{
	int nActCount = GetFormFieldCount();
	for (int iFieldIndex = 1; iFieldIndex <= nActCount; iFieldIndex++)
	{
		DPLFlattenFormField(InstanceID, iFieldIndex);
	}
	return 1;
}

int XPubPDFForm::UpdateAndFlattenAnnotations()
{
	int nAnnotationCount = AnnotationCount();
	//for (int iAnnotIndex = 1; iAnnotIndex <= nAnnotationCount; ++iAnnotIndex)
	//{
	//	DPLSetAnnotIntProperty(InstanceID, iAnnotIndex, 131, 1);
	//}
	for (int idx = 1; idx < 50; ++idx) {
		for (int iAnnotIndex = 1; iAnnotIndex <= nAnnotationCount; ++iAnnotIndex)
			DPLFlattenAnnot(InstanceID, iAnnotIndex, 0);
	}
	return 1;
}

int XPubPDFForm::UpdateAppearanceStreams()
{
	int nActCount = GetFormFieldCount();
	for(int iFieldIndex = 1; iFieldIndex <= nActCount; iFieldIndex++)
	{
		DPLUpdateAppearanceStream(InstanceID, iFieldIndex);
	}
	return 1;
}

int XPubPDFForm::FindFormFieldByTitle(const std::string& formfield)
{
    int nFrmField = DPLFindFormFieldByTitleA(InstanceID, (char*)formfield.c_str());
    if(nFrmField)  return nFrmField;

    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
    std::wstring wformfield = converter.from_bytes(formfield);
	return DPLFindFormFieldByTitle(InstanceID, (wchar_t*)formfield.c_str());
}

char* XPubPDFForm::GetFormFieldValueByTitle(const std::string& formfield)
{
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;

    std::wstring wformfield = converter.from_bytes(formfield);
    wchar_t *frmValue = DPLGetFormFieldValueByTitle(InstanceID, (wchar_t*)wformfield.c_str());

    std::string u8_conv = converter.to_bytes(frmValue);
 
	return (char*)u8_conv.c_str();
}

int XPubPDFForm::GetFormFieldKidCount(const int Index)
{
	return DPLGetFormFieldKidCount(InstanceID, Index);
}

int XPubPDFForm::SetFormFieldValueByTitle(const std::string& formfield, const std::string& value)
{
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
    std::wstring wvalue = converter.from_bytes(value);
    std::wstring wformfield = converter.from_bytes(formfield);
	return DPLSetFormFieldValueByTitle(InstanceID, (wchar_t*)wformfield.c_str(), (wchar_t*)wvalue.c_str());
}

char* XPubPDFForm::GetFormFieldTitle(const int Index)
{
	return DPLGetFormFieldTitleA(InstanceID, Index);
}

int XPubPDFForm::GetFormFieldCount()
{
	return DPLFormFieldCount(InstanceID);
}

int XPubPDFForm::GetPageCount()
{
	return DPLSelectedDocument(InstanceID);
}

int XPubPDFForm::GetFormFieldType(const int Index)
{
	return DPLGetFormFieldType(InstanceID, Index);
}

int XPubPDFForm::GetPageCount(int DocumentID) 
{
	return DPLDAGetPageCount(InstanceID, DocumentID);
}

int XPubPDFForm::SelectPage(int PageNumber)
{
	return DPLDAGetPageCount(InstanceID, PageNumber);
}

int XPubPDFForm::AnnotationCount()
{
	return DPLAnnotationCount(InstanceID);
}

int XPubPDFForm::GetAnnotActionID(int Index)
{
	return DPLGetAnnotActionID(InstanceID, Index);
}

char* XPubPDFForm::GetActionURL(int ActionID)
{
	return DPLGetActionURLA(InstanceID, ActionID);
}

char* XPubPDFForm::GetActionType(int ActionID)
{
	return DPLGetActionTypeA(InstanceID, ActionID);
}

// Merging
int XPubPDFForm::SelectedDocument()
{
	return DPLSelectedDocument(InstanceID);
}

int XPubPDFForm::SelectDocument(int DocumentID)
{
	return DPLSelectDocument(InstanceID, DocumentID);
}

int XPubPDFForm::MergeDocument(int DocumentID)
{
	return DPLMergeDocument(InstanceID, DocumentID);
}

int XPubPDFForm::AddToFileList(const std::string& list, const std::string& filename)
{
	return DPLAddToFileListA(InstanceID, (char*)list.c_str(), (char*)filename.c_str());
}

int XPubPDFForm::SaveMergeList(const std::string& list, const std::string& filename)
{
	return DPLMergeFileListA(InstanceID, (char*)list.c_str(), (char*)filename.c_str());
}

