#ifdef XPUBPDFFORM_EXPORTS
#define XPUBPDFFORM_API __declspec(dllexport)
#else
#define XPUBPDFFORM_API __declspec(dllimport)
#endif

#include <string>

// This class is exported from the XPubPDFForm.dll
class XPUBPDFFORM_API XPubPDFForm {
public:
    XPubPDFForm();
    ~XPubPDFForm();

    int LoadFromFile(const std::string& FileName);
    int SaveToFile(const std::string& FileName);

    // Formfield

    int UpdateAndFlattenFormFields();
	int UpdateAndFlattenAnnotations(); 
    int UpdateAppearanceStreams();

    int FindFormFieldByTitle(const std::string& formfield);
    char* GetFormFieldValueByTitle(const std::string& formfield);
    int GetFormFieldKidCount(const int Index);
    int SetFormFieldValueByTitle(const std::string& formfield, const std::string& value);
    char* GetFormFieldTitle(const int Index);
    int GetFormFieldCount();
    int GetPageCount();
	int GetFormFieldType(const int Index);

	// Removing hyperlink from page 1
	int GetPageCount(int DocumentID);
	int SelectPage(int PageNumber);
	int AnnotationCount();
	int GetAnnotActionID(int Index);
	char* GetActionURL(int ActionID);
	char* GetActionType(int ActionID);

    // Merging
    int SelectedDocument();
    int SelectDocument(int DocumentID);
	int MergeDocument(int DocumentID);

	int AddToFileList(const std::string& list, const std::string& filename);
	int SaveMergeList(const std::string& list, const std::string& filename);

protected:
    int InstanceID;

};

