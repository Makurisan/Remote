// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"
#include "PDFLibrary.h"

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{ 
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		DEBENUPDFLIBRARYLIB1512_DllMain(hModule, DLL_PROCESS_ATTACH, NULL);
		break;
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		DEBENUPDFLIBRARYLIB1512_DllMain(hModule, DLL_PROCESS_DETACH, NULL);
		break;
	}
	return TRUE;
}

